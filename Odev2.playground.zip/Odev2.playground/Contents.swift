import UIKit

class Odev {
    //1
    func dereceDonustur(derece: Double) -> Double {
        return (derece * 1.8) + 32.0
    }
    //2
    func dikdortgenCevre(kisaKenar: Int, uzunKenar: Int) -> Int{
        return (kisaKenar + uzunKenar)*2
    }
    //3
    func faktoriyel(sayi: Int) -> Int {
        var sonuc = 1
        if (sayi > 0) {
            for i in 1...sayi {
                sonuc = sonuc * i
            }
                    
        }
        return sonuc
    }
    //4
    func harfSayisi(kelime: String, harf: Character) -> Int {
        let letters = Array(kelime);
        var count = 0;
        for letter in letters {
            if letter == harf {
                count += 1
            }
        }
       return count
    }
    //5
    func icAci (kenarSayisi: Int) -> Int {
        var n = kenarSayisi
        let icAcilarToplami = (n - 2) * 180
         return icAcilarToplami
    }
    //6
    func saat(x:Int) -> Int {
            if (x<=160) {
             print(10 * x)
            }else {
            print(1600 + 20 * (x-160))
            }
        
            return 0
 }
    //7
    func kota(a:Int) -> Int {
        
            if (a>50) {
             print((a-50) * 4 + 100)
            }else {
            print(100)
            }
       
            return toplam
}
}
let x = Odev ()

print("Fahrenhiet                            : \(x.dereceDonustur(derece: 35.3))")
print("Dikdörtgenin Çevresi                  : \(x.dikdortgenCevre(kisaKenar: 8, uzunKenar: 15))")
print("Faktoriyel Hesaplama                  : \(x.faktoriyel(sayi: 11))")
print("Kelimede Seçilen Harf Sayısı          : \(x.harfSayisi(kelime: "matematik", harf: "m"))")
print("Kenar Sayısına Göre İç Açılar Toplamı : \(x.icAci(kenarSayisi: 5))")

let m = Odev ()
m.saat(x: 170)

let h = Odev ()
let toplam = h.kota(a: 55)


